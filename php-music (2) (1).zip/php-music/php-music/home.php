<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mx-auto my-5 py5">
        <div class="card shadow rounded-0">
            <div class="card-body rounded-0">
                <div class="container-fluid">
                    <?= html_entity_decode(file_get_contents(base_app."welcome.html")) ?>
                </div>
            </div>
        </div>
    </div>
</div>